package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lote")
public class Lote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idLote")
    private Long id;

    @Column(name = "dataAquisic")
    private LocalDate dataAquisic;

    @Column(name = "quantidade")
    private Integer quantidade;

    @Column(name = "preco_unitario")
    private Double precoUnitario;

    // N:1 com Sementes
    @ManyToOne
    @JoinColumn(name = "Sementes_idSementes", nullable = false)
    private Sementes sementes;

    // N:1 com Fornecedor
    @ManyToOne
    @JoinColumn(name = "Fornecedor_idFornecedor")
    private Fornecedor fornecedor;

    // 1:N com ItemPedido
    @OneToMany(mappedBy = "lote", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemPedido> itensPedido;


    public Lote() {
    }

    public Lote(LocalDate dataAquisic, Integer quantidade, Double precoUnitario, Sementes sementes, Fornecedor fornecedor) {
        this.dataAquisic = dataAquisic;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.sementes = sementes;
        this.fornecedor = fornecedor;
    }

    // getters e setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDataAquisic() {
        return dataAquisic;
    }

    public void setDataAquisic(LocalDate dataAquisic) {
        this.dataAquisic = dataAquisic;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public Double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(Double precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public Sementes getSementes() {
        return sementes;
    }

    public void setSementes(Sementes sementes) {
        this.sementes = sementes;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public List<ItemPedido> getItensPedido() {
        return itensPedido;
    }

    public void setItensPedido(List<ItemPedido> itensPedido) {
        this.itensPedido = itensPedido;
    }
}