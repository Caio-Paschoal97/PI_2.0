package pe.senac.br.backend.repository;

import pe.senac.br.backend.model.Sementes;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SementesRepository extends JpaRepository<Sementes, Long> {
    // REMOVA todas as consultas @Query por enquanto
    List<Sementes> findByDistribuidorId(Long distribuidorId);
}