package pe.senac.br.backend.dto;

import java.time.LocalDate;

public class LoteDTO {
    private Long id;
    private LocalDate dataAquisic;
    private Integer quantidade;
    private Double precoUnitario;
    private SementesDTO sementes;
    private FornecedorDTO fornecedor;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public LocalDate getDataAquisic() {
		return dataAquisic;
	}
	public void setDataAquisic(LocalDate dataAquisic) {
		this.dataAquisic = dataAquisic;
	}
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	public Double getPrecoUnitario() {
		return precoUnitario;
	}
	public void setPrecoUnitario(Double precoUnitario) {
		this.precoUnitario = precoUnitario;
	}
	public SementesDTO getSementes() {
		return sementes;
	}
	public void setSementes(SementesDTO sementes) {
		this.sementes = sementes;
	}
	public FornecedorDTO getFornecedor() {
		return fornecedor;
	}
	public void setFornecedor(FornecedorDTO fornecedor) {
		this.fornecedor = fornecedor;
	}

    // getters e setters
}