package pe.senac.br.backend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "distribuidor")
public class Distribuidor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idDistribuidor")
    private Long id;

    @Column(name = "dataDistrib")
    private LocalDateTime dataDistrib;

    // 1:1 com Usuario
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id_usuario", nullable = false)
    private Usuario usuario;


    // 1:N com Sementes
    @OneToMany(mappedBy = "distribuidor")
    private List<Sementes> sementes = new ArrayList<>();

    public Distribuidor() {
    }

    public Distribuidor(LocalDateTime dataDistrib, Usuario usuario) {
        this.dataDistrib = dataDistrib;
        this.usuario = usuario;
    }

    // getters e setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getDataDistrib() {
        return dataDistrib;
    }

    public void setDataDistrib(LocalDateTime dataDistrib) {
        this.dataDistrib = dataDistrib;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Sementes> getSementes() {
        return sementes;
    }

    public void setSementes(List<Sementes> sementes) {
        this.sementes = sementes;
    }
}