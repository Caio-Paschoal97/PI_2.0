package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.PedidoDTO;
import pe.senac.br.backend.dto.ClienteDTO;
import pe.senac.br.backend.model.Pedido;
import pe.senac.br.backend.model.Cliente;
import pe.senac.br.backend.repository.PedidoRepository;
import pe.senac.br.backend.repository.ClienteRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/pedidos")
@CrossOrigin(origins = "http://localhost:3000")
public class PedidoController {

    private final PedidoRepository pedidoRepository;
    private final ClienteRepository clienteRepository;

    public PedidoController(PedidoRepository pedidoRepository, ClienteRepository clienteRepository) {
        this.pedidoRepository = pedidoRepository;
        this.clienteRepository = clienteRepository;
    }

    @GetMapping
    public List<PedidoDTO> listar() {
        return pedidoRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PedidoDTO> buscarPorId(@PathVariable Long id) {
        return pedidoRepository.findById(id)
                .map(pedido -> ResponseEntity.ok(toDTO(pedido)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/cliente/{clienteId}")
    public List<PedidoDTO> buscarPorCliente(@PathVariable Long clienteId) {
        return pedidoRepository.findByClienteId(clienteId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/status/{status}")
    public List<PedidoDTO> buscarPorStatus(@PathVariable String status) {
        return pedidoRepository.findByStatus(status)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @PostMapping
    public ResponseEntity<PedidoDTO> criar(@RequestBody PedidoDTO dto) {
        Cliente cliente = clienteRepository.findById(dto.getCliente().getId())
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado"));
        
        Pedido pedido = fromDTO(dto);
        pedido.setCliente(cliente);
        Pedido salvo = pedidoRepository.save(pedido);
        return ResponseEntity.ok(toDTO(salvo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PedidoDTO> atualizar(@PathVariable Long id, @RequestBody PedidoDTO dto) {
        return pedidoRepository.findById(id)
                .map(existente -> {
                    existente.setStatus(dto.getStatus());
                    Pedido atualizado = pedidoRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<PedidoDTO> atualizarStatus(@PathVariable Long id, @RequestBody String status) {
        return pedidoRepository.findById(id)
                .map(existente -> {
                    existente.setStatus(status);
                    Pedido atualizado = pedidoRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!pedidoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        pedidoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private PedidoDTO toDTO(Pedido pedido) {
        PedidoDTO dto = new PedidoDTO();
        dto.setId(pedido.getId());
        dto.setStatus(pedido.getStatus());
        dto.setDataPedido(pedido.getDataPedido());

        if (pedido.getCliente() != null) {
            ClienteDTO cli = new ClienteDTO();
            cli.setId(pedido.getCliente().getId());
            cli.setNome(pedido.getCliente().getNome());
            cli.setCpf(pedido.getCliente().getCpf());
            dto.setCliente(cli);
        }

        return dto;
    }

    private Pedido fromDTO(PedidoDTO dto) {
        Pedido pedido = new Pedido();
        pedido.setStatus(dto.getStatus());
        pedido.setDataPedido(dto.getDataPedido() != null ? dto.getDataPedido() : LocalDateTime.now());
        return pedido;
    }
}