package pe.senac.br.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "itempedido")
public class ItemPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idItemPedido")
    private Long id;

    @Column(name = "quantPedida")
    private Integer quantPedida;

    @Column(name = "preco_venda")
    private Double precoVenda;

    // N:1 com Pedido
    @ManyToOne
    @JoinColumn(name = "Pedido_idPedido", nullable = false)
    private Pedido pedido;

    // N:1 com Lote
    @ManyToOne
    @JoinColumn(name = "Lote_idLote", nullable = false)
    private Lote lote;

    public ItemPedido() {
    }

    public ItemPedido(Integer quantPedida, Double precoVenda, Pedido pedido, Lote lote) {
        this.quantPedida = quantPedida;
        this.precoVenda = precoVenda;
        this.pedido = pedido;
        this.lote = lote;
    }

    // getters e setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getQuantPedida() {
        return quantPedida;
    }

    public void setQuantPedida(Integer quantPedida) {
        this.quantPedida = quantPedida;
    }

    public Double getPrecoVenda() {
        return precoVenda;
    }

    public void setPrecoVenda(Double precoVenda) {
        this.precoVenda = precoVenda;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public Lote getLote() {
        return lote;
    }

    public void setLote(Lote lote) {
        this.lote = lote;
    }
}