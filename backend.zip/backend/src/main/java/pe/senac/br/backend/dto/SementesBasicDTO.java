package pe.senac.br.backend.dto;

import java.time.LocalDate;

public class SementesBasicDTO {
    private Long id;
    private String nomeComum;
    private String nomeCientifico;
    private String fabricante;
    private LocalDate dataValidade;
    private Integer quantidadeEstoque;

    // Construtor para a query do Repository
    public SementesBasicDTO(Long id, String nomeComum, String nomeCientifico, 
                           String fabricante, LocalDate dataValidade, Integer quantidadeEstoque) {
        this.id = id;
        this.nomeComum = nomeComum;
        this.nomeCientifico = nomeCientifico;
        this.fabricante = fabricante;
        this.dataValidade = dataValidade;
        this.quantidadeEstoque = quantidadeEstoque;
    }

    // Getters e Setters
    // ...
}