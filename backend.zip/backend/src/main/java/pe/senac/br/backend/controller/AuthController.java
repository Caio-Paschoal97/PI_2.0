package pe.senac.br.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.senac.br.backend.dto.LoginDTO;
import pe.senac.br.backend.dto.UsuarioDTO;
import pe.senac.br.backend.model.Usuario;
import pe.senac.br.backend.service.AuthService;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) {
        boolean autenticado = authService.autenticar(loginDTO.getLogin(), loginDTO.getSenha());
        
        if (autenticado) {
            Optional<Usuario> usuarioOpt = authService.buscarPorLogin(loginDTO.getLogin());
            if (usuarioOpt.isPresent()) {
                Usuario usuario = usuarioOpt.get();
                
                Map<String, Object> response = new HashMap<>();
                response.put("autenticado", true);
                response.put("mensagem", "Login realizado com sucesso");
                response.put("usuario", toUsuarioDTO(usuario));
                
                return ResponseEntity.ok(response);
            }
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("autenticado", false);
        response.put("mensagem", "Login ou senha inválidos");
        return ResponseEntity.status(401).body(response);
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registrar(@RequestBody LoginDTO registroDTO) {
        try {
            if (authService.usuarioExiste(registroDTO.getLogin())) {
                Map<String, Object> response = new HashMap<>();
                response.put("sucesso", false);
                response.put("mensagem", "Usuário já existe");
                return ResponseEntity.badRequest().body(response);
            }
            
            Usuario usuario = authService.criarUsuario(registroDTO.getLogin(), registroDTO.getSenha());
            
            Map<String, Object> response = new HashMap<>();
            response.put("sucesso", true);
            response.put("mensagem", "Usuário criado com sucesso");
            response.put("usuario", toUsuarioDTO(usuario));
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("sucesso", false);
            response.put("mensagem", "Erro ao criar usuário: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/alterar-senha")
    public ResponseEntity<?> alterarSenha(@RequestBody LoginDTO alterarSenhaDTO) {
        boolean sucesso = authService.atualizarSenha(alterarSenhaDTO.getLogin(), alterarSenhaDTO.getSenha());
        
        Map<String, Object> response = new HashMap<>();
        if (sucesso) {
            response.put("sucesso", true);
            response.put("mensagem", "Senha alterada com sucesso");
            return ResponseEntity.ok(response);
        } else {
            response.put("sucesso", false);
            response.put("mensagem", "Usuário não encontrado");
            return ResponseEntity.status(404).body(response);
        }
    }

    @GetMapping("/verificar/{login}")
    public ResponseEntity<?> verificarUsuario(@PathVariable String login) {
        boolean existe = authService.usuarioExiste(login);
        
        Map<String, Object> response = new HashMap<>();
        response.put("existe", existe);
        return ResponseEntity.ok(response);
    }

    private UsuarioDTO toUsuarioDTO(Usuario usuario) {
        UsuarioDTO dto = new UsuarioDTO();
        dto.setId(usuario.getId());
        dto.setLogin(usuario.getLogin());
        // Não retornamos a senha por segurança
        return dto;
    }
}