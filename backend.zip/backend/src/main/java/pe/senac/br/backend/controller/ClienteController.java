package pe.senac.br.backend.controller;

import pe.senac.br.backend.dto.ClienteDTO;
import pe.senac.br.backend.dto.UsuarioDTO;
import pe.senac.br.backend.model.Cliente;
import pe.senac.br.backend.model.Usuario;
import pe.senac.br.backend.repository.ClienteRepository;
import pe.senac.br.backend.repository.UsuarioRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/clientes")
@CrossOrigin(origins = "http://localhost:3000")
public class ClienteController {

    private final ClienteRepository clienteRepository;
    private final UsuarioRepository usuarioRepository;

    public ClienteController(ClienteRepository clienteRepository, UsuarioRepository usuarioRepository) {
        this.clienteRepository = clienteRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    public List<ClienteDTO> listar() {
        return clienteRepository.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteDTO> buscarPorId(@PathVariable Long id) {
        return clienteRepository.findById(id)
                .map(cliente -> ResponseEntity.ok(toDTO(cliente)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ClienteDTO> criar(@RequestBody ClienteDTO dto) {
        // Verificar se o usuário já existe
        if (dto.getUsuario() != null && dto.getUsuario().getId() != null) {
            Usuario usuario = usuarioRepository.findById(dto.getUsuario().getId())
                    .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
            
            // Verificar se já existe um cliente com este usuário
            if (clienteRepository.findByUsuarioId(dto.getUsuario().getId()).isPresent()) {
                return ResponseEntity.badRequest().build();
            }
            
            Cliente cliente = fromDTO(dto);
            cliente.setUsuario(usuario);
            Cliente salvo = clienteRepository.save(cliente);
            return ResponseEntity.ok(toDTO(salvo));
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClienteDTO> atualizar(@PathVariable Long id, @RequestBody ClienteDTO dto) {
        return clienteRepository.findById(id)
                .map(existente -> {
                    existente.setNome(dto.getNome());
                    existente.setCpf(dto.getCpf());

                    // Atualizar dados do usuário se fornecido
                    if (dto.getUsuario() != null && existente.getUsuario() != null) {
                        UsuarioDTO u = dto.getUsuario();
                        Usuario usuario = existente.getUsuario();
                        usuario.setLogin(u.getLogin());
                        // Nota: Normalmente não atualizamos a senha diretamente assim
                        // Em um caso real, teríamos um método específico para atualizar senha
                        if (u.getSenha() != null && !u.getSenha().isEmpty()) {
                            usuario.setSenha(u.getSenha());
                        }
                    }

                    Cliente atualizado = clienteRepository.save(existente);
                    return ResponseEntity.ok(toDTO(atualizado));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!clienteRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        clienteRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Métodos auxiliares para busca
    @GetMapping("/cpf/{cpf}")
    public ResponseEntity<ClienteDTO> buscarPorCpf(@PathVariable String cpf) {
        return clienteRepository.findByCpf(cpf)
                .map(cliente -> ResponseEntity.ok(toDTO(cliente)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<ClienteDTO> buscarPorUsuarioId(@PathVariable Long usuarioId) {
        return clienteRepository.findByUsuarioId(usuarioId)
                .map(cliente -> ResponseEntity.ok(toDTO(cliente)))
                .orElse(ResponseEntity.notFound().build());
    }

    // Conversões

    private ClienteDTO toDTO(Cliente cliente) {
        ClienteDTO dto = new ClienteDTO();
        dto.setId(cliente.getId());
        dto.setNome(cliente.getNome());
        dto.setCpf(cliente.getCpf());

        if (cliente.getUsuario() != null) {
            UsuarioDTO u = new UsuarioDTO();
            u.setId(cliente.getUsuario().getId());
            u.setLogin(cliente.getUsuario().getLogin());
            u.setSenha(cliente.getUsuario().getSenha());
            dto.setUsuario(u);
        }

        return dto;
    }

    private Cliente fromDTO(ClienteDTO dto) {
        Cliente cliente = new Cliente();
        cliente.setNome(dto.getNome());
        cliente.setCpf(dto.getCpf());

        // O usuário deve ser gerenciado separadamente
        // Em um cenário real, você pode querer criar o usuário primeiro
        if (dto.getUsuario() != null && dto.getUsuario().getId() != null) {
            Usuario usuario = usuarioRepository.findById(dto.getUsuario().getId())
                    .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
            cliente.setUsuario(usuario);
        }

        return cliente;
    }
}